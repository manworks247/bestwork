"""Business Entity Resolution Package"""
