import json
import os

ROOT = os.path.dirname(os.path.abspath(__file__))
sm_nb_path = os.path.join(ROOT, "entity_resolution_project", "amazon_sagemaker", "sagemaker_pipeline.ipynb")

cells = [
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "# Amazon SageMaker: Business Entity Resolution Pipeline\n",
            "### Scalable Inverted Index Blocking, Vectorized Feature Extraction & Macro $F_{0.5}$ GBDT Matcher\n",
            "\n",
            "---\n",
            "\n",
            "### Overview\n",
            "This notebook provides the complete workflow to execute the Business Entity Resolution pipeline on **AWS SageMaker**.\n",
            "It supports both:\n",
            "1. **Direct Studio / Notebook Execution**: Run directly in a SageMaker Studio notebook or on a single `ml.m5.2xlarge` / `ml.c5.4xlarge` instance.\n",
            "2. **SageMaker Managed Training & Processing Jobs**: Launch decoupled, serverless spot/on-demand compute instances running `sagemaker_train_and_inference.py`.\n",
            "\n",
            "---"
        ]
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "## 1. Install & Import Dependencies"
        ]
    },
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Install pure-algorithm packages and AWS SDK\n",
            "!pip install -q rapidfuzz lightgbm scikit-learn pandas numpy tqdm boto3 sagemaker\n",
            "\n",
            "import os\n",
            "import sys\n",
            "import json\n",
            "import time\n",
            "import shutil\n",
            "import zipfile\n",
            "import boto3\n",
            "import sagemaker\n",
            "from sagemaker import get_execution_role\n",
            "\n",
            "print(\"Dependencies loaded successfully.\")"
        ]
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "## 2. Configure AWS Environment, IAM Role & S3 Bucket"
        ]
    },
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Initialize SageMaker session and default S3 bucket\n",
            "try:\n",
            "    role = get_execution_role()\n",
            "    sess = sagemaker.Session()\n",
            "    bucket = sess.default_bucket()\n",
            "    region = sess.boto_region_name\n",
            "    print(f\"AWS SageMaker Session Initialized:\")\n",
            "    print(f\"  Region:  {region}\")\n",
            "    print(f\"  Bucket:  {bucket}\")\n",
            "    print(f\"  IAM Role: {role}\")\n",
            "except Exception as e:\n",
            "    print(f\"Local environment / running outside AWS SageMaker Studio: {e}\")\n",
            "    role = None\n",
            "    bucket = None\n",
            "\n",
            "# Prefix for entity resolution pipeline data in S3\n",
            "S3_PREFIX = \"amazon-ml-challenge-2026/entity-resolution\"\n",
            "LOCAL_DATA_DIR = \"dataset\"\n",
            "OUTPUT_DIR = \"output\"\n",
            "MODEL_DIR = \"models\"\n",
            "\n",
            "os.makedirs(OUTPUT_DIR, exist_ok=True)\n",
            "os.makedirs(MODEL_DIR, exist_ok=True)"
        ]
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "## 3. S3 Data Synchronization\n",
            "Sync the training and test dataset between local filesystem and AWS S3."
        ]
    },
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Upload local dataset to S3 (if running in SageMaker Studio with local dataset)\n",
            "if bucket and os.path.exists(LOCAL_DATA_DIR):\n",
            "    print(f\"Uploading local dataset to s3://{bucket}/{S3_PREFIX}/dataset ...\")\n",
            "    sess.upload_data(path=LOCAL_DATA_DIR, bucket=bucket, key_prefix=f\"{S3_PREFIX}/dataset\")\n",
            "    print(\"S3 Upload Complete!\")\n",
            "elif bucket:\n",
            "    print(f\"Download dataset from S3 if present:\")\n",
            "    print(f\"  aws s3 sync s3://{bucket}/{S3_PREFIX}/dataset {LOCAL_DATA_DIR}/\")"
        ]
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "## 4. Run End-to-End Pipeline in SageMaker Studio / Notebook Instance\n",
            "Executes training, threshold optimization, and vectorized inference on all 1,732,544 test entities."
        ]
    },
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Run the production entrypoint script sagemaker_train_and_inference.py\n",
            "t0 = time.time()\n",
            "!python sagemaker_train_and_inference.py \\\n",
            "    --version 1 \\\n",
            "    --train {LOCAL_DATA_DIR} \\\n",
            "    --test {LOCAL_DATA_DIR} \\\n",
            "    --model-dir {MODEL_DIR} \\\n",
            "    --output-data-dir {OUTPUT_DIR} \\\n",
            "    --train-samples 50000 \\\n",
            "    --mode all\n",
            "\n",
            "print(f\"Local pipeline execution completed in {time.time() - t0:.2f} seconds.\")"
        ]
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "## 5. Launch Scalable AWS SageMaker Training Job (Managed Compute Mode)\n",
            "Launches an isolated SageMaker managed job on `ml.c5.4xlarge` or `ml.m5.2xlarge` compute."
        ]
    },
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "from sagemaker.sklearn.estimator import SKLearn\n",
            "\n",
            "if role and bucket:\n",
            "    print(\"Configuring SageMaker SKLearn Estimator for remote managed execution...\")\n",
            "    estimator = SKLearn(\n",
            "        entry_point=\"sagemaker_train_and_inference.py\",\n",
            "        source_dir=\".\",\n",
            "        role=role,\n",
            "        instance_count=1,\n",
            "        instance_type=\"ml.c5.4xlarge\",  # 16 vCPUs, 32 GiB RAM for fast inference\n",
            "        framework_version=\"1.2-1\",\n",
            "        py_version=\"py3\",\n",
            "        hyperparameters={\n",
            "            \"version\": 1,\n",
            "            \"train-samples\": 50000,\n",
            "            \"mode\": \"all\",\n",
            "        },\n",
            "        use_spot_instances=True,  # Cost-effective spot instances (saves up to 70%)\n",
            "        max_wait=14400,\n",
            "        max_run=10800,\n",
            "    )\n",
            "    print(\"To launch the job, uncomment and run: estimator.fit({'train': f's3://{bucket}/{S3_PREFIX}/dataset/train', 'test': f's3://{bucket}/{S3_PREFIX}/dataset/test'})\")\n",
            "else:\n",
            "    print(\"Skipping managed job config: No active AWS credentials or IAM role.\")"
        ]
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "## 6. Official Submission Validator Check\n",
            "Verifies formatting, exact row counts (1,732,544 rows), column headers, and ID constraints."
        ]
    },
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "validator_script = \"student_resource/utils/validate_submission.py\"\n",
            "if not os.path.exists(validator_script):\n",
            "    validator_script = \"utils/validate_submission.py\"\n",
            "\n",
            "test_dir = os.path.join(LOCAL_DATA_DIR, \"test\") if os.path.exists(os.path.join(LOCAL_DATA_DIR, \"test\")) else LOCAL_DATA_DIR\n",
            "\n",
            "!python {validator_script} \\\n",
            "    --matching {OUTPUT_DIR}/matching_results.tsv \\\n",
            "    --candidate {OUTPUT_DIR}/candidate_pairs.tsv \\\n",
            "    --test-dir {test_dir}"
        ]
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "## 7. Package Final Submission Zip & Sync to S3\n",
            "Bundles outputs, source code, and methodology documentation, and uploads to Amazon S3."
        ]
    },
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Create submission.zip\n",
            "ZIP_PATH = \"submission.zip\"\n",
            "print(f\"Creating {ZIP_PATH}...\")\n",
            "\n",
            "with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as zf:\n",
            "    # 1. Output TSVs and CSV\n",
            "    zf.write(f\"{OUTPUT_DIR}/matching_results.tsv\", \"output/matching_results.tsv\")\n",
            "    zf.write(f\"{OUTPUT_DIR}/candidate_pairs.tsv\", \"output/candidate_pairs.tsv\")\n",
            "    csv_path = f\"{OUTPUT_DIR}/matching_pairs.csv\"\n",
            "    if os.path.exists(csv_path):\n",
            "        zf.write(csv_path, \"output/matching_pairs.csv\")\n",
            "    print(\"  + Added output files\")\n",
            "\n",
            "    # 2. Documentation\n",
            "    doc_path = \"Documentation_template.md\"\n",
            "    if not os.path.exists(doc_path):\n",
            "        doc_path = \"student_resource/Documentation_template.md\"\n",
            "    if os.path.exists(doc_path):\n",
            "        zf.write(doc_path, \"Documentation_template.md\")\n",
            "        print(\"  + Added Documentation_template.md\")\n",
            "\n",
            "    # 3. Source code\n",
            "    code_src_dir = \"src\"\n",
            "    for root, dirs, files in os.walk(code_src_dir):\n",
            "        for f in files:\n",
            "            if not f.endswith(\".pyc\"):\n",
            "                full_p = os.path.join(root, f)\n",
            "                zf.write(full_p, os.path.join(\"code/business_entity_resolution\", full_p))\n",
            "    zf.write(\"sagemaker_train_and_inference.py\", \"code/business_entity_resolution/run_pipeline.py\")\n",
            "    zf.write(\"requirements.txt\", \"code/business_entity_resolution/requirements.txt\")\n",
            "    zf.write(\"README.md\", \"code/business_entity_resolution/README.md\")\n",
            "    print(\"  + Added source code under code/business_entity_resolution/\")\n",
            "\n",
            "print(f\"\\n[SUCCESS] Built {ZIP_PATH} ({os.path.getsize(ZIP_PATH):,} bytes).\")\n",
            "\n",
            "# Sync to S3 bucket\n",
            "if bucket:\n",
            "    s3_dest = f\"s3://{bucket}/{S3_PREFIX}/submissions/{ZIP_PATH}\"\n",
            "    print(f\"Syncing submission to S3: {s3_dest} ...\")\n",
            "    sess.upload_data(path=ZIP_PATH, bucket=bucket, key_prefix=f\"{S3_PREFIX}/submissions\")\n",
            "    print(f\"[OK] Uploaded to S3 successfully!\")"
        ]
    }
]

nb_dict = {
    "cells": cells,
    "metadata": {
        "language_info": {"name": "python"},
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}
    },
    "nbformat": 4,
    "nbformat_minor": 2
}

with open(sm_nb_path, "w", encoding="utf-8") as f:
    json.dump(nb_dict, f, indent=1)

print(f"Successfully generated upgraded SageMaker pipeline notebook: {sm_nb_path} ({os.path.getsize(sm_nb_path):,} bytes)")
